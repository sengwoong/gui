#!/bin/bash

conda env remove -n sdco

