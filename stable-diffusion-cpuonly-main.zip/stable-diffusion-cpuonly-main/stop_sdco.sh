#!/bin/bash

conda deactivate 
