#!/bin/bash
conda activate sdco
python ./webui.py --no-half
